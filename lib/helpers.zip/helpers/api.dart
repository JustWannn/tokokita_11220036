import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:tokokita/helpers/user_info.dart';
import 'app_exception.dart';

class Api {
  // Perform POST request with data
  Future<dynamic> post(dynamic url, dynamic data) async {
    var token = await UserInfo().getToken();
    dynamic responseJson; // Explicitly define responseJson as dynamic

    try {
      final response = await http.post(
        Uri.parse(url), // Ensure URL is properly parsed
        headers: {
          HttpHeaders.authorizationHeader: 'Bearer $token',
          'Content-Type':
              'application/json', // Optional: Adjust content type if needed
        },
        body: data, // Assuming data is a Map or a valid request body
      );
      responseJson = _returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet connection');
    } catch (e) {
      throw FetchDataException('An error occurred: $e');
    }

    return responseJson;
  }

  // Perform GET request
  Future<dynamic> get(dynamic url) async {
    var token = await UserInfo().getToken();
    dynamic responseJson; // Explicitly define responseJson as dynamic

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {HttpHeaders.authorizationHeader: 'Bearer $token'},
      );
      responseJson = _returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet connection');
    } catch (e) {
      throw FetchDataException('An error occurred: $e');
    }

    return responseJson;
  }

  // Perform DELETE request
  Future<dynamic> delete(dynamic url) async {
    var token = await UserInfo().getToken();
    dynamic responseJson; // Explicitly define responseJson as dynamic

    try {
      final response = await http.delete(
        Uri.parse(url),
        headers: {HttpHeaders.authorizationHeader: 'Bearer $token'},
      );
      responseJson = _returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet connection');
    } catch (e) {
      throw FetchDataException('An error occurred: $e');
    }

    return responseJson;
  }

  // Handle HTTP response status codes and errors
  dynamic _returnResponse(http.Response response) {
    switch (response.statusCode) {
      case 200:
        return response.body; // Successful response
      case 400:
        throw BadRequestException(response.body.toString());
      case 401:
        throw UnauthorizedException(response.body.toString());
      case 422:
        throw InvalidInputException(response.body.toString());
      case 500:
        throw FetchDataException(
            'Error occurred while communicating with the server. StatusCode: ${response.statusCode}');
      default:
        throw FetchDataException(
            'Error occurred while communicating with the server. StatusCode: ${response.statusCode}');
    }
  }
}
